<?php

return [
    'permissions_role' => [
        'Danh sách',
        'Thêm',
        'Sửa',
        'Xóa'
    ]
];