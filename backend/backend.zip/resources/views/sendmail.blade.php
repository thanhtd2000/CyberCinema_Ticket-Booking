<b>Chào bạn</b>
<p>
    <i>Đây là mã code để xác thực thay đổi mật khẩu
        {{ $code }} có thời hạn trong vòng 15 phút<br> Hãy nhấn vào <a
            href="{{ BASE_URL }}checkcode?email={{ $email }}">đây</a> để đổi mật khẩu</i>
</p>
