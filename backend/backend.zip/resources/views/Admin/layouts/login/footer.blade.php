<script src="../../../dist/vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <script src="../../../dist/vendors/simplebar/js/simplebar.min.js"></script>
    <script>
    </script>

  </body>
</html>