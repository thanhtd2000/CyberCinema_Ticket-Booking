<footer class="footer">
    <div class="ms-auto">Powered by&nbsp;<a href="index">Cinema Movie Team</a></div>
</footer>
<!-- CoreUI and necessary plugins-->
<script src="{{asset('dist
/vendors/@coreui/coreui/js/coreui.bundle.min.js')}}"></script>
<script src="{{asset('dist
/vendors/simplebar/js/simplebar.min.js')}}"></script>
<!-- Plugins and scripts required by this view-->
<script src="{{asset('dist
/vendors/chart.js/js/chart.min.js')}}"></script>
<script src="{{asset('dist
/vendors/@coreui/chartjs/js/coreui-chartjs.js')}}"></script>
<script src="{{asset('dist
/vendors/@coreui/utils/js/coreui-utils.js')}}"></script>
<script src="{{asset('dist
/js/main.js')}}"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
@yield('js')

</body>

</html>
