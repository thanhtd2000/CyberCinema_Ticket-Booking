<script src="../../../dist/vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <script src="../../../dist/vendors/simplebar/js/simplebar.min.js"></script>
    <script>
    </script>

  </body>
</html><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\layouts\login\footer.blade.php ENDPATH**/ ?>