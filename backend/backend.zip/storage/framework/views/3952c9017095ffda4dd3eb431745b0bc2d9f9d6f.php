


<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <button type="submit" class="btn btn-primary "><a class="text-white" href="<?php echo e(route('admin.discount.create')); ?>">Thêm
                mới</a></button>
        <div class="row g-3 align-items-center ">
            <form action="<?php echo e(route('admin.discount.search')); ?>" method="POST" class="d-flex">
                <?php echo csrf_field(); ?>
                <div class="col-auto">
                    <input type="text" name="keywords" id="inputEmail6" value="<?php echo e(isset($keywords) ? $keywords : ''); ?>"
                        class="form-control" placeholder="Nhập từ khoá">
                </div>
                <button type="submit" class="btn btn-primary text-white">Tìm kiếm</button>
            </form>
        </div>
    </div>

    <br>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Mã giảm giá</th>
                <th scope="col">Tiền tối thiểu áp dụng</th>
                <th scope="col">Tiền tối đa triết khấu</th>
                <th scope="col">Số lượng</th>
                <th scope="col">Thời gian áp dụng</th>
                <th scope="col">Thời gian kết thúc</th>
                <th scope="col">Phần trăm triết khấu</th>
                <th scope="col">Mô tả</th>
                <th scope="col">Chức năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key += 1); ?></th>
                    <td><?php echo e($discount->code); ?></td>
                    <td><?php echo e(number_format($discount->min_price, 0, ',', '.')); ?> VNĐ</td>
                    <td><?php echo e(number_format($discount->max_price, 0, ',', '.')); ?> VNĐ</td>
                    <td><?php echo e($discount->count); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($discount->start_time))); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($discount->end_time))); ?></td>
                    <td><?php echo e($discount->percent); ?>%</td>
                    <td><?php echo e($discount->description); ?></td>
                    <td>
                        <button class="btn btn-primary">
                            <a class="text-white" href="<?php echo e(route('admin.discount.edit', $discount->id)); ?>"><i
                                    class="fas fa-pencil-alt"></i></a>
                        </button>
                        <button class="btn btn-danger">
                            <a class="text-white" onclick="return confirm('Bạn có chắc chắn muốn xóa không?')"
                                href="<?php echo e(route('admin.discount.delete', $discount->id)); ?>"><i
                                    class="fas fa-trash-alt"></i></a>
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($discounts->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\discounts\list.blade.php ENDPATH**/ ?>