


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.discount.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Mã giảm giá</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="code" value="<?php echo e(old('code')); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('code')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('code')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Số lượng</label>
            <input type="number" class="form-control" id="exampleInputEmail1" name="count" value="<?php echo e(old('count')); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('count')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('count')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Ngày áp dụng</label>
            <input type="date" name="start_time" class="form-control" value="<?php echo e(old('start_time')); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('start_time')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('start_time')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Ngày kết thúc</label>
            <input type="date" name="end_time" class="form-control" value="<?php echo e(old('end_time')); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('end_time')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('end_time')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Phần trăm triết khấu</label>
            <input type="number" name="percent" class="form-control" value="<?php echo e(old('percent')); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('percent')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('percent')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Mô tả</label>
            <input class="form-control" type="text" name="description">
        </div>
        <div class="error">
            <?php if($errors->has('description')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('description')); ?>

                </span>
            <?php endif; ?>
        </div>

        <br>
        <button type="submit" class="btn btn-primary">Thêm mới</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\discounts\create.blade.php ENDPATH**/ ?>