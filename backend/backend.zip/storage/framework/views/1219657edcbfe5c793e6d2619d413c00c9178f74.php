


<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <button type="button" class="btn btn-primary col-md-1"><a class="text-white" href="<?php echo e(route('admin.director.create')); ?>">Thêm mới</a></button>
        <div class="row g-3 align-items-center col-md-4">
            <form action="<?php echo e(route('admin.director.search')); ?>" method="POST" class="d-flex">
                <?php echo csrf_field(); ?>
                <div class="col-auto">
                    <input type="text" name="keywords" id="inputEmail6" value="<?php echo e(isset($keywords) ? $keywords : ''); ?>"
                        class="form-control" placeholder="Nhập từ khoá">
                </div>
                <button type="submit" class="btn btn-primary text-white ms-3">Tìm kiếm</button>
            </form>
        </div>
        <div class="col-md-4"></div>
    </div>
    <br>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Ảnh</th>
                <th scope="col">Tên diễn vên</th>
                <th scope="col">Ngày sinh</th>
                <th scope="col">Quốc tịch</th>
                <th scope="col">Giới tính</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key += 1); ?></th>
                    <td><img src="<?php echo e($director->image); ?>" alt="" width="50"></td>
                    <td><?php echo e($director->name); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($director->birthday))); ?></td>
                    <td><?php echo e($director->nationality); ?></td>
                    <td><?php echo e($director->gender == 1 ? 'Nam' : ($director->gender == 2 ? 'Nữ' : 'Khác')); ?></td>
                    <td>
                        <button class="btn btn-primary">
                            <a class="text-white" href="<?php echo e(route('admin.director.edit', $director->id)); ?>">Sửa</a>
                        </button>
                        <button class="btn btn-danger">
                            <a class="text-white" onclick="return confirm('Really delete this director?')"
                                href="<?php echo e(route('admin.director.destroy', $director->id)); ?>"> Xóa</a>
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($directors->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\directors\index.blade.php ENDPATH**/ ?>