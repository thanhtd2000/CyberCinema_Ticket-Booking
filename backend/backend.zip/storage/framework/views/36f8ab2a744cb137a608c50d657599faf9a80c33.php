



<?php $__env->startSection('content'); ?>
    <div class="bg-light min-vh-100 d-flex flex-row align-items-center">
        <div class="container">
            <div class="message text-center">
                <?php if(session('message')): ?>
                    <p class="aler text-danger pt-3 pb-3">
                        <strong><?php echo e(session('message')); ?></strong>
                    </p>
                <?php endif; ?>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card-group d-block d-md-flex row">
                        <div class="card col-md-7 p-4 mb-0">
                            <div class="card-body">
                                <h1>Đăng Nhập</h1>
                                <p class="text-medium-emphasis">Đăng nhập tài khoản của bạn</p>
                                <form action="<?php echo e(route('checkLogin')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group mb-3"><span class="input-group-text">
                                            <svg class="icon">
                                                <use xlink:href="../../../dist/vendors/@coreui/icons/svg/free.svg#cil-user">
                                                </use>
                                            </svg></span>
                                        <input class="form-control" type="text" name="email" placeholder="Email"
                                            value="<?php echo e(old('email')); ?>">
                                    </div>
                                    <div class="error">
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger fs-6">
                                                <?php echo e($errors->first('email')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="input-group mb-4"><span class="input-group-text">
                                            <svg class="icon">
                                                <use
                                                    xlink:href="../../../dist/vendors/@coreui/icons/svg/free.svg#cil-lock-locked">
                                                </use>
                                            </svg></span>
                                        <input class="form-control" name="password" type="password" placeholder="Password">
                                    </div>
                                    <div class="error">
                                        <?php if($errors->has('password')): ?>
                                            <p class="text-danger fs-6">
                                                <?php echo e($errors->first('password')); ?>

                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="row">

                                        <div class=" d-flex">
                                            <input type="checkbox" name="remember">
                                            <label for="">Lưu đăng nhập</label>
                                        </div>
                                        <div class="col-6">
                                            <button class="btn btn-primary px-4" type="submit">Đăng nhập</button>
                                        </div>
                                </form>


                            </div>
                        </div>
                    </div>
                    <div class="card col-md-5 text-white bg-primary py-5">
                        <div class="card-body text-center">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.login.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.login.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.login.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\login.blade.php ENDPATH**/ ?>