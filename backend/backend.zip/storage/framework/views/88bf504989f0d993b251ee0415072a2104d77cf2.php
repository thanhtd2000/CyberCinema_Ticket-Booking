


<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between"> <button type="button" class="btn btn-primary"><a
                class="text-white" href="create">Thêm mới</a></button>
        <div class="row g-3 align-items-center">
            <form action="<?php echo e(route('users.search')); ?>" method="POST" class="d-flex">
                <?php echo csrf_field(); ?>
                <div class="col-auto">
                    <input type="text" name="keywords" id="inputEmail6" value="<?php echo e(isset($keywords) ? $keywords : ''); ?>"
                        class="form-control" placeholder="Nhập từ khoá">
                </div>
                <button type="submit" class="btn btn-primary text-white ms-3">Tìm kiếm</button>
            </form>
        </div>
    </div>
    <br>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Tên người dùng</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Avatar</th>
                <th scope="col">Thời gian tạo</th>
                <th scope="col">Chức năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($us->role != 0): ?>
                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td><?php echo e($us->name); ?></td>
                        <td><?php echo e($us->email); ?></td>
                        <td><?php echo e($roles[$us->role] ?? ''); ?></td>
                        <td><img src="<?php echo e($us->image); ?>" width="30px" alt=""></td>
                        <td><?php echo e($us->created_at); ?></td>
                        <td>
                            <?php if(!$us->role == 0 && $us->id != Auth::user()->id): ?>
                                <a class="text-white btn btn-success" href="edit/<?php echo e($us->id); ?>"><i
                                        class="fas fa-pencil-alt"></i></a>
                                <a class="btn btn-danger" onclick=" return confirm('Bạn có chắc chắn xoá?')"
                                    href="delete/<?php echo e($us->id); ?>"><i class="fas fa-trash-alt"></i></a>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($user->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\user\index.blade.php ENDPATH**/ ?>