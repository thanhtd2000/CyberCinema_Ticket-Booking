


<?php $__env->startSection('content'); ?>
<div class="row">
   
    
    <form method="POST" action="<?php echo e(route('admin.room.store')); ?>" class="container">
        <?php echo csrf_field(); ?>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Tên phòng</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
        
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>        
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Số hàng</label>
                <input type="number" name="row" class="form-control" value="<?php echo e(old('row')); ?>" min="1" max="10">
        
                <?php $__errorArgs = ['row'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>        
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label">Số cột</label>
                <input type="number" name="column" class="form-control" value="<?php echo e(old('column')); ?>" min="1" max="10">
        
                <?php $__errorArgs = ['column'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>        
        </div>
       
        <button type="submit" class="btn btn-outline-primary">Submit</button>
    </form>
</div>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\Room\create.blade.php ENDPATH**/ ?>