


<?php $__env->startSection('content'); ?>

  


        <form method="POST" action="<?php echo e(route('permission.update')); ?>" class="container">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="col-md-6" style="padding-left: 0">
                <div class="mb-3">
                    <label class="form-label">Tên quyền</label>
                    <input type="hidden" name="parent_id" value="<?php echo e($permission_parent->id); ?>">
                    <input type="text" name="permission_parent" class="form-control" value="<?php echo e($permission_parent->name); ?>" readonly>

                    <?php $__errorArgs = ['permission_parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1" style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $permission_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permissionChildItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="custom-control custom-switch col-md-3">
                    <input type="checkbox" class="custom-control-input" id="customSwitch<?php echo e($key); ?>"  <?php echo e($permissionChildItem->check == 1 ? 'checked' : ''); ?> value="<?php echo e($permissionChildItem->id); ?>" name="permission_child[]" >
                    <label class="custom-control-label" for="customSwitch<?php echo e($key); ?>"><?php echo e($permissionChildItem->name); ?></label>
                  </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <button type="submit" class="btn btn-outline-primary mt-3">Submit</button>
        </form>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\user\permission\edit.blade.php ENDPATH**/ ?>