


<?php $__env->startSection('content'); ?>
    <button type="button" class="btn btn-primary"><a class="text-white" href="create">Thêm mới</a></button>
    <br>
    <br>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Tên người dùng</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Avatar</th>
                <th scope="col">Thời gian tạo</th>
                <th scope="col">Chức năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key + 1); ?></th>
                    <td><?php echo e($us->name); ?></td>
                    <td><?php echo e($us->email); ?></td>
                    <td><?php echo e($roles[$us->role] ?? ''); ?>

                    </td>
                    <td><img src="../../../uploads/<?php echo e($us->avatar); ?>" width="30px" alt=""></td>
                    <td><?php echo e($us->created_at); ?></td>
                    <td>
                        <?php if($us->role != 0): ?>
                            <?php if(!in_array($us->role, [2, 3])): ?>
                                <button type="button" class="btn btn-success">
                                    <a class="text-white" onclick="return confirm('Bạn có chắc chắn muốn chuyển quyền?')"
                                        href="<?php echo e(route('users.permise1', ['id' => $us->id, 'stt' => 3])); ?>">Kiểm duyệt</a>
                                </button>
                            <?php endif; ?>
                            <?php if(in_array($us->role, [1, 3])): ?>
                                <button type="button" class="btn btn-danger">
                                    <a class="text-white" onclick="return confirm('Bạn có chắc chắn block?')"
                                        href="<?php echo e(route('users.permise1', ['id' => $us->id, 'stt' => 2])); ?>">Block</a>
                                </button>
                            <?php endif; ?>
                            <?php if(!in_array($us->role, [1, 2])): ?>
                                <button type="button" class="btn btn-info">
                                    <a class="text-white" onclick="return confirm('Bạn có chắc chắn muốn chuyển quyền?')"
                                        href="<?php echo e(route('users.permise1', ['id' => $us->id, 'stt' => 1])); ?>">Thành viên</a>
                                </button>
                            <?php endif; ?>
                            <?php if($us->role == 2): ?>
                                <button type="button" class="btn btn-success">
                                    <a class="text-white" onclick="return confirm('Bạn có chắc chắn muốn chuyển quyền?')"
                                        href="<?php echo e(route('users.permise1', ['id' => $us->id, 'stt' => 3])); ?>">Kiểm duyệt</a>
                                </button>
                                <button type="button" class="btn btn-info">
                                    <a class="text-white" onclick="return confirm('Bạn có chắc chắn muốn chuyển quyền?')"
                                        href="<?php echo e(route('users.permise1', ['id' => $us->id, 'stt' => 1])); ?>">Thành viên</a>
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($user->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\user\permise.blade.php ENDPATH**/ ?>