<b>Chào bạn</b>
<p>
    <i>Đây là mã code để xác thực thay đổi mật khẩu
        <?php echo e($code); ?> có thời hạn trong vòng 15 phút<br> Hãy nhấn vào <a
            href="<?php echo e(BASE_URL); ?>checkcode?email=<?php echo e($email); ?>">đây</a> để đổi mật khẩu</i>
</p>
<?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\sendmail.blade.php ENDPATH**/ ?>