


<?php $__env->startSection('content'); ?>
    <div class="row">


        <form method="POST" action="<?php echo e(route('admin.room.update',['id'=>$room->id])); ?>" class="container">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="col-md-6" style="padding: 0">
                <div class="mb-3">
                    <label class="form-label">Tên phòng</label>
                    <input type="text" name="roomname" class="form-control" value="<?php echo e($room->name); ?>">

                    <?php $__errorArgs = ['roomname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class=" mt-1" style="color: red"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


            </div>

            
            <div class="row">
                <div class="col-md-9">
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php for($j = 1; $j <= $room->column; $j++): ?>
                            <?php if(
                                $seats->contains(function ($t) use ($element, $j) {
                                    return $t->name == $element . $j;
                                })): ?>
                                <?php
                                    $seat = $seats->first(function ($t) use ($element, $j) {
                                        return $t->name == $element . $j;
                                    });
                                ?>
                                <?php if($seat->status == 0): ?>
                                    <a <?php if($seat->type_id == 1): ?> class="btn btn-success seat-detail"
                                    <?php elseif($seat->type_id == 2): ?> class="btn btn-primary seat-detail"
                                    <?php elseif($seat->type_id == 3): ?> class="btn btn-danger seat-detail" <?php endif; ?>
                                        style="width: 55px; margin:5px" data-toggle="modal" data-target="#seats"
                                        data-seat-id="<?php echo e($seat->id); ?>">
                                        <?php echo e($element . $j); ?>

                                    </a>
                                <?php elseif($seat->status == 1): ?>
                                    <a class="btn btn-outline-dark seat-detail" style="width: 55px; margin:5px" data-toggle="modal"
                                        data-target="#seats" data-seat-id="<?php echo e($seat->id); ?>"><?php echo e($element . $j); ?></a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-3" style="padding: 0">
                    <h6>Ghi chú</h6>
                    <div class="note-seat" style="margin-top: 20px; display: -webkit-box;">
                        <img src="../../../uploads/note-room/thuong.png" alt="" width="40">
                        <p style="margin-left: 10px">Ghế thường</p>
                    </div>
                    <div class="note-seat" style="margin-top: 20px;display: -webkit-box;">
                        <img src="../../../uploads/note-room/vip.png" alt="" width="40">
                        <p style="margin-left: 10px">Ghế vip</p>
                    </div>
                    <div class="note-seat" style="margin-top: 20px;display: -webkit-box;">
                        <img src="../../../uploads/note-room/doi.png" alt="" width="40">
                        <p style="margin-left: 10px">Ghế đôi</p>
                    </div>
                    <div class="note-seat" style="margin-top: 20px;display: -webkit-box;">
                        <img src="../../../uploads/note-room/noeseat.png" alt="" width="40">
                        <p style="margin-left: 10px">Ghế không sử dụng</p>
                    </div>

                </div>
            </div>
          
            <button type="submit" class="btn btn-outline-primary">Submit</button>
        </form>
    </div>

    <div class="modal fade" id="seats" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ghế</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    

                    <div class="mb-3">
                        <label class="form-label">Tên Ghế</label>
                        <input type="hidden" id="seat-id" value="">
                        <input type="text" name="name" class="form-control name" id="name" value=""
                            readonly>

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Loại ghế</label>
                        <select class="form-control type" id="type">
                            <?php $__currentLoopData = $seatType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Trạng thái</label>
                        <select class="form-control type" id="status">
                           
                                <option value="0">Sử dụng </option>
                                <option value="1"> Không sử dụng </option>
                            
                        </select>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                    <button type="button" class="btn btn-primary save-seat">Lưu </button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        //    $(document).on("click", ".seat", function(e) {
        //     e.preventDefault();
        //     var seat_id = $(this).data('seat-id');

        //     $.ajax({
        //         url: 'admin/seats/edit/' + seat_id,
        //         method: 'GET',
        //         success: function(data) {
        //             var seatData = data;
        //             showModal(seatData)
        //         }
        //     })
        //    });
        //    function showModal(seatData){
        //       $('.name').val(seatData.name);
        //       $('.type').val(seatData.type_id);

        //       $('#seats').modal('show');
        //    }

        $(document).on('click', '.seat-detail', function(e) {
            var seat_id = $(this).data('seat-id');
            // console.log(seat_id);
            $('#seats').modal('show');
            $.ajax({
                url: '/admin/seats/edit/' + seat_id,
                type: 'GET',
                success: function(response) {

                    $('#seat-id').val(response.seat.id);
                    $('#name').val(response.seat.name);
                    $('#type').val(response.seat.type_id);
                    $('#status').val(response.seat.status);



                }
            });
        });


        $(document).on('click', '.save-seat', function(e) {
            e.preventDefault();
            var seat_id = $('#seat-id').val();
            var data = {
                'type_id': $('#type').val(),
                'status' : $('#status').val()
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/admin/seats/update/' + seat_id,
                type: 'PUT',
                data: data,
                // dataType: 'json',
                success: function(data) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Thành công',
                        text: 'Cập nhật dữ liệu thành công.',
                        showConfirmButton: false,
                        timer: 1000,
                        timerProgressBar: true
                    }).then(function() {
                        // Sau khi popup đóng, load lại trang
                        location.reload();
                    });


                }
            });
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\Room\edit.blade.php ENDPATH**/ ?>