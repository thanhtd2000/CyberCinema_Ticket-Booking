


<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('admin.movie.update', $movie->id)); ?>" class="container" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Tên Phim</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($movie->name); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('name')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('name')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Mô Tả</label>
            <input type="text" name="description" class="form-control" value="<?php echo e($movie->description); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('description')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('description')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Ngày ra mắt</label>
            <input type="date" name="date" class="form-control" value="<?php echo e($movie->date); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('date')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('date')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Tác Giả</label>
            <select class="js-example-basic-multiple-limit form-control" name="director_id" multiple="multiple">
                <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($movie->director_id === $item->id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>">
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="error">
            <?php if($errors->has('director_id')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('director_id')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Link Trailer</label>
            <input type="text" name="trailer" class="form-control" value="<?php echo e($movie->trailer); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('trailer')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('trailer')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Thời Lượng Phim</label>
            <input type="text" name="time" class="form-control" value="<?php echo e($movie->time); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('time')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('time')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Ngôn Ngữ</label>
            <input type="text" name="language" class="form-control" value="<?php echo e($movie->language); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('language')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('language')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Ảnh</label>
            <input type="file" name="image" class="form-control" value="<?php echo e(old('image')); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('image')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('image')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label class="form-label">Giá Phim</label>
            <input type="number" name="price" class="form-control" value="<?php echo e($movie->price); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('price')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('price')); ?>

                </span>
            <?php endif; ?>
        </div>
        <label for="">Diễn Viên</label>
        <select class="js-example-basic-hide-search-multi form-control form-select" name="actors[]"
            id="js-example-basic-hide-search-multi" multiple="multiple">
            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e($movie->actors->contains('id', $item->id) ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>">
                    <?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <label for="">Thể Loại</label>
        <select class=" form-control form-select" name="category_id">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e($movie->category_id === $item->id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>">
                    <?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <div class="mb-3">
            <label class="form-label text-danger">Thuộc tính HOT</label>
            <input type="checkbox" class="form-check-input" name="isHot" <?php echo e($movie->isHot == 0 ? 'checked' : ''); ?>>
        </div><br>
        <div class="mb-3">
            <label class="form-label">Giới hạn từ bao nhiêu tuổi trở lên</label>
            <input type="number" name="year_old" class="form-control" value="<?php echo e($movie->year_old); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('year_old')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('year_old')); ?>

                </span>
            <?php endif; ?>
        </div><br>
        <div class="mb-3">
            <label class="form-label">Loại Phim (2D hay 3D ...)</label>
            <input type="text" name="type" class="form-control" value="<?php echo e($movie->type); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('type')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('type')); ?>

                </span>
            <?php endif; ?>
        </div>
        <br>
        <button type="submit" class="btn btn-outline-primary">Xác nhận</button>
    </form>

    <?php echo $__env->make('Admin.layouts.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\movie\edit.blade.php ENDPATH**/ ?>