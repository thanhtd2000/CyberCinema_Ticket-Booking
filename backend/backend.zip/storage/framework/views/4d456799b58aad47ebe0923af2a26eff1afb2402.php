


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.product.update', $product->id)); ?>" method="POST" class="container"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Tên sản phẩm</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="name" aria-describedby="emailHelp"
                value="<?php echo e($product->name); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('name')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('name')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Giá</label>
            <input type="number" class="form-control" id="exampleInputEmail1" name="price" aria-describedby="emailHelp"
                value="<?php echo e($product->price); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('price')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('price')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Số lượng</label>
            <input type="number" class="form-control" id="exampleInputEmail1" name="count" aria-describedby="emailHelp"
                value="<?php echo e($product->count); ?>">
        </div>
        <div class="error">
            <?php if($errors->has('count')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('count')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Ảnh</label>
            <input type="file" name="image" class="form-control" value="<?php echo e(old('image')); ?>">
            <img src="<?php echo e($product->image); ?>" width="100" alt="">
        </div>
        <div class="error">
            <?php if($errors->has('image')): ?>
                <span class="text-danger fs-6">
                    <?php echo e($errors->first('image')); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Mô tả</label>
            <textarea name="description" id="" cols="30" rows="10"><?php echo e($product->description); ?></textarea>
        </div>
        <div class="error">
            <?php if($errors->has('description')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('description')); ?>

                </span>
            <?php endif; ?>
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\products\edit.blade.php ENDPATH**/ ?>