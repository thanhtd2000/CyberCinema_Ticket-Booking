


<?php $__env->startSection('content'); ?>
    <form class="col-md-8" action="<?php echo e(route('post-create')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Tiêu đề</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="title" aria-describedby="emailHelp">
        </div>
        <div class="error">
            <?php if($errors->has('title')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('title')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Nội dung</label>
            <textarea name="content" id="editor"></textarea>
        </div>
        <div class="error">
            <?php if($errors->has('content')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('content')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Ảnh</label>
            <input type="file" class="form-control" id="exampleInputEmail1" name="image" aria-describedby="emailHelp">
            <div id="emailHelp" class="form-text">Thêm ảnh hiển thị đại diện</div>
        </div>
        <div class="error">
            <?php if($errors->has('image')): ?>
                <span class="text-danger fs-5">
                    <?php echo e($errors->first('image')); ?>

                </span>
            <?php endif; ?>
        </div>
        <br>
        <div class="mb-3">
            <select name="category" id="">
                <option value="1">Tin Tức</option>
                <option value="2">Ưu Đãi</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Thêm</button>
    </form>
    <script src=<?php echo e(url('ckeditor/ckeditor.js')); ?>></script>
    <script>
        CKEDITOR.replace('editor', {
            filebrowserBrowseUrl: '<?php echo e(asset('ckfinder/ckfinder.html')); ?>',
            filebrowserImageBrowseUrl: '<?php echo e(asset('ckfinder/ckfinder.html?type=Images')); ?>',
            filebrowserFlashBrowseUrl: '<?php echo e(asset('ckfinder/ckfinder.html?type=Flash')); ?>',
            filebrowserUploadUrl: '<?php echo e(asset('ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files')); ?>',
            filebrowserImageUploadUrl: '<?php echo e(asset('ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images')); ?>',
            filebrowserFlashUploadUrl: '<?php echo e(asset('ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash')); ?>',
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\post\create.blade.php ENDPATH**/ ?>