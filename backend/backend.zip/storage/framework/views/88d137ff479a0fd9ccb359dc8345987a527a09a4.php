<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between"> <button type="button" class="btn btn-primary"><a
                class="text-white" href="create">Thêm mới</a></button>
        <div class="row g-3 align-items-center">
            <form action="<?php echo e(route('posts.search')); ?>" method="POST" class="d-flex">
                <?php echo csrf_field(); ?>
                <div class="col-auto">
                    <input type="text" name="keywords" id="inputEmail6" class="form-control" placeholder="Nhập từ khoá">
                </div>
                <button type="button" class="btn btn-primary text-white ms-3">Tìm kiếm</button>
            </form>
        </div>
    </div>
    <form action="<?php echo e(route('delete.Mulposts')); ?>" method="POST" class="mt-1">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Check</th>
                    <th scope="col">STT</th>
                    <th scope="col">Tiêu đề</th>
                    
                    <th scope="col">Ảnh</th>
                    <th scope="col">Thời gian đăng</th>
                    
                    <th scope="col">Người đăng</th>
                    <th scope="col">Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th>
                            <?php if($post->user->role != 0 || $post->user->id == Auth::id()): ?>
                                <input type="checkbox" name="ids[]" value="<?php echo e($post->id); ?>">
                            <?php else: ?>
                                <h4 class="text-danger">ADMIN</h4>
                            <?php endif; ?>
                        </th>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td>
                            <p
                                style=" white-space: nowrap;
                        width:300px;
                        overflow: hidden;">
                                <?php echo e($post->title); ?></p>
                        </td>
                        
                        <td><img src="<?php echo e($post->image); ?>" width="50px" alt=""></td>
                        <td><?php echo e($post->created_at); ?></td>
                        
                        <td><?php echo e($post->user->name); ?></td>
                        <td class="whitespace-nowrap">
                            <?php if($post->user->role != 0 || Auth::user()->id == $post->user->id): ?>
                                <a class="btn btn-success" href="edit/<?php echo e($post->id); ?>"><i
                                        class="fas fa-pencil-alt"></i></a> <a class="btn btn-danger"
                                    onclick=" return confirm('Bạn có chắc chắn xoá?')" href="delete/<?php echo e($post->id); ?>"><i
                                        class="fas fa-trash-alt"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table><button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá?')">Xoá
            mục đã
            chọn</button>
    </form>
    <div class="mt-1"><?php echo e($posts->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\post\index.blade.php ENDPATH**/ ?>