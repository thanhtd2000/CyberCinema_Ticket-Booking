


<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between"> <button type="button" class="btn btn-primary"><a
                class="text-white" href="">Thêm mới</a></button>
        <div class="row align-items-center">
            <form action="" method="POST" class="d-flex">
                <?php echo csrf_field(); ?>
                <div class="col-auto">
                    <input type="text" name="keywords" id="inputEmail6" class="form-control" placeholder="Tìm kiếm theo ngày">
                </div>
                <div class="col-auto">
                    <input type="text" name="keywords" id="inputEmail6" class="form-control" placeholder="Tìm kiếm theo ngày">
                </div>
                <button type="submit" class="btn btn-primary text-white ms-3">Tìm kiếm</button>
            </form>
        </div>
    </div>
    <table class="table mt-2">
        <thead>
            <tr>
                <th class="">STT</th>
                
                <th class="">Mã giao dịch</th>
                <th class="">Mã hóa đơn</th>
                <th class="">Ngân hàng</th>
                <th class="">Hình thức TT</th>
                <th class="">Trạng thái</th>
                <th class="">Số tiền</th>
                <th class="">Thời gian GD</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class=""><?php echo e($key += 1); ?></td>
                    
                    
                    <td class="" style="font-weight: bold"><?php echo e($transaction->transactions_code); ?></td>
                    <td class=""><?php echo e($transaction->order_code); ?></td>
                    <td class=""><?php echo e($transaction->bank_code); ?></td>
                    <td class=""><?php echo e($transaction->payment_code); ?></td>
                    <td class="">
                       
                    <?php if($transaction->status === 2): ?>
                       <button type="button" class="btn btn-success" style="width:140px ; font-size: 14px ; font-weight:bold"> Đã thanh toán</button>
                    <?php else: ?>
                        <button type="button" class="btn btn-danger" style="width:140px ; font-size: 14px ;font-weight:bold">Đã hủy</button>
                    <?php endif; ?>
                    <td class="" style="font-weight: bold"><?php echo e(number_format($transaction->amount )); ?> VND</td>
                   
                    <td class=""><?php echo e($transaction->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($transactions->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\transactions\index.blade.php ENDPATH**/ ?>