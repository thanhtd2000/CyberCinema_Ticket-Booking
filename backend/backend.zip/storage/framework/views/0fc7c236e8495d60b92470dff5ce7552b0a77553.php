


<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('admin.schedule.store')); ?>" class="container">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Phim</label>
            <select class="js-example-basic-multiple-limit form-control" name="movie_id" multiple="multiple">
                
                <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php $__errorArgs = ['movie_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="exampleFormControlSelect1">Phòng</label>
            <select class="js-example-basic-multiple-limit form-control type" name="room_id" id="type" multiple="multiple">
                
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php $__errorArgs = ['room_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div id="additionalDates">
            <div class="form-group">
                <label for="exampleFormControlSelect1">Ngày chiếu</label>
                <button type="button" class="btn btn-outline-success" style="font-size: 15px; margin: 10px;" id="addDateBtn"><i class="fas fa-plus"></i></button>
                <input type="datetime-local" name="time_start[]" class="form-control" value="<?php echo e(old('time_start')); ?>">
            </div>
        </div>


        <button type="submit" class="btn btn-outline-primary">Thêm mới</button>
    </form>

    <?php echo $__env->make('Admin.layouts.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            var counter = 1;

            $('#addDateBtn').click(function() {
                var html = '<div class="form-group">' +
                           '<label for="exampleFormControlSelect1">Ngày chiếu</label>' +
                           '<input type="datetime-local" name="time_start[]" class="form-control" value="<?php echo e(old('time_start')); ?>">' +
                           '</div>';

                $('#additionalDates').append(html);
                counter++;
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\schedule\create.blade.php ENDPATH**/ ?>