


<?php $__env->startSection('content'); ?>
    <form class="col-md-8" action="<?php echo e(route('user.post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Tên Người Dùng</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="name" value="<?php echo e(old('name')); ?>"
                aria-describedby="emailHelp">
            <?php if($errors->has('name')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('name')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Email</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="email" value="<?php echo e(old('email')); ?>"
                aria-describedby="emailHelp">
            <?php if($errors->has('email')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('email')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Avatar</label>
            <input type="file" class="form-control" id="exampleInputEmail1" name="image" value="<?php echo e(old('image')); ?>"
                aria-describedby="emailHelp">
            <?php if($errors->has('image')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('image')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" value="<?php echo e(old('password')); ?>"
                name="password" aria-describedby="emailHelp">
            <?php if($errors->has('password')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('password')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Reapet Password</label>
            <input type="password" class="form-control" id="exampleInputEmail1"
                name="password_confirmation"value="<?php echo e(old('password_confirmation')); ?>" aria-describedby="emailHelp">
            <?php if($errors->has('password_confirmation')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('password_confirmation')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Số điện thoại</label>
            <input type="number" class="form-control" id="exampleInputEmail1" name="phone" value="<?php echo e(old('phone')); ?>"
                aria-describedby="emailHelp">
            <?php if($errors->has('phone')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('phone')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Ngày Sinh</label>
            <input type="date" class="form-control" id="exampleInputEmail1" name="birthday"
                value="<?php echo e(old('birthday')); ?>" aria-describedby="emailHelp">
            <?php if($errors->has('birthday')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('birthday')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Giới Tính</label>
            <select class="form-select" name="sex" aria-label="Default select example">
                <option value="1">Nam</option>
                <option value="2">Nữ</option>
                <option value="3">Khác</option>
            </select>
            <?php if($errors->has('sex')): ?>
                <span class="text-danger fs-3">
                    <?php echo e($errors->first('sex')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Vai trò</label>
            <select class="form-select" name="role" aria-label="Default select example">
                <option value="1">Thành viên</option>
                <option value="3">Kiểm Duyệt Viên</option>
            </select>
        </div>
        <br>

        <button type="submit" class="btn btn-primary">Thêm</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\user\create.blade.php ENDPATH**/ ?>