<div class="body flex-grow-1 px-3">

    <?php if(\Session::has('message') && \Session::has('errors')): ?>
        <div class="alert alert-success">
            <ul style="margin: 0">
                <li id="message" style="list-style: none"><?php echo \Session::get('message'); ?></li>
            </ul>
        </div>
        <div class="alert alert-danger">
            <ul style="margin: 0">
                <li id="message" style="list-style: none"><?php echo \Session::get('errors'); ?></li>
            </ul>
        </div>
    <?php elseif(Session::has('errors')): ?>
    <script>
        toastr.options = {
            "progressBar" : true,
            'timeOut'     : 1500,
        }
        toastr.error("<?php echo e(Session::get('errors')); ?>");
     </script>
    <?php elseif(Session::has('message')): ?>
         <script>
            toastr.options = {
                "progressBar" : true,
                'timeOut'     : 1000,
            }
            toastr.success("<?php echo e(Session::get('message')); ?>",{timeOut:100});
         </script>
        
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\layouts\master.blade.php ENDPATH**/ ?>