


<?php $__env->startSection('content'); ?>

<button class="btn btn-primary">
    <a class="text-white" href="<?php echo e(route('admin.seat_row.create')); ?>">Thêm</a>
</button>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            
            <th scope="col">Action</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $seatRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $seatRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($key+=1); ?></th>
                <td><?php echo e($seatRow->name); ?></td>
               
               
                <td>
                    <a class="btn btn-success" href="<?php echo e(route('admin.seat_row.edit', $seatRow->id)); ?>"><i class="fas fa-pencil-alt"></i> </a>
                    <a class="btn btn-danger"   OnClick='return confirm("Are you want to delete ?");' href="<?php echo e(route('admin.seat_row.delete', $seatRow->id)); ?>"><i class="fas fa-trash-alt"></i> </a>
                  
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="col-md-12">


    <?php echo e($seatRows->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\seats\seat_row\list.blade.php ENDPATH**/ ?>