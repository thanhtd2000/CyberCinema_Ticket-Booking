


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">

            <canvas id="chartMonth" ></canvas>
        </div>
    </div>
    <div class="month" style="display: flex">

        <?php $__currentLoopData = $orderMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button class="btn btn-primary month-button" type="button" data-toggle="collapse" data-target="#collapseExample"
                aria-expanded="false" aria-controls="collapseExample-<?php echo e($order->order_month); ?>" style="margin: 10px"
                data-month=<?php echo e($order->order_month); ?>>
                <?php echo e($order->order_month); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="collapse" id="collapseExample">
        <div class="card card-body" style="padding: 0">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Ngày</th>
                        <th scope="col">Doanh số</th>
                    </tr>
                </thead>
                <tbody class="data-container">
                </tbody>
            </table>
        </div>
    </div>


  
    <script>
        const chartData = JSON.parse('<?php echo $chartData; ?>');
        console.log(chartData)
        const ctx = document.getElementById('chartMonth');

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: chartData.datasets.label,
                    data: chartData.datasets.data,
                    borderWidth: chartData.datasets.borderWidth
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
    <script>
        $(document).on('click', '.month-button', function(e) {
            var month = $(this).data('month');
            $.ajax({
                url: '/admin/showMonth' ,
                type: 'GET',
                data: {
                    month: month
                },
                dataType: 'json',
                success: function(data) {
                    // console.log(data.month);
                    const tableBody = $('.data-container');
                    tableBody.empty(); // Xóa dữ liệu cũ trước khi đổ mới
                    data.month.forEach (function(item) {
                        tableBody.append('<tr><td>' + item.order_date + '</td><td>' + new Intl.NumberFormat().format(item.total_sum)  + ' VND </td></tr>');
                    })
                },
                error: function(error) {
                    console.error('Error while fetching data:', error);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WE17202_PHP1\du_an_tot_nghiep\backend\resources\views\Admin\statisticals\index.blade.php ENDPATH**/ ?>