<?php

namespace App\Helpers;

use GuzzleHttp\Client;

class ShortenLink
{
    protected $apiKey;

    public function __construct($apiKey)
    {
        $this->apiKey = $apiKey;
    }

    public function shorten($url)
    {
        $client = new Client();

        $response = $client->request('POST', 'https://api-ssl.bitly.com/v4/shorten', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'long_url' => $url,
            ],
        ]);

        $data = json_decode($response->getBody()->getContents(), true);

        return $data['id'];
    }
}
